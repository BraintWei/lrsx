'''--------------------------本地配置====================='''
# confingData={
#     'DomainName':'http://127.0.0.1:5008',
#     "Img_return":"http://127.0.0.1:5008/static",
#     'mysqlPassword':"123.",
#     'mysqlHost':'127.0.0.1',
#
#     #字体地址列表
#     "zitilist":[    "./ziti/青叶手写体.ttf", "./ziti/李国夫手写体.ttf", "./ziti/义启手写体.ttf", "./ziti/云烟体.ttf",
#                     "./ziti/jmt.ttf","./ziti/extrabold.ttf", "./ziti/BoLeYaYati.ttf", "./ziti/伯乐童年体.ttf",
#                     "./ziti/FZJingLeiS-R-GB.ttf","./ziti/DFPHanziPenW3-GB.ttf","./ziti/李国夫手写体ERRO.ttf",
#                     "./ziti/义启手写体ERRO.ttf", "./ziti/云烟体ERRO.ttf", "./ziti/jmtERRO.ttf",
#                     "./ziti/extraboldERRO.ttf", "./ziti/BoLeYaYatiERRO.ttf", "./ziti/伯乐童年体ERRO.ttf",
#                     "./ziti/FZJingLeiS-R-GBERRO.ttf","./ziti/DFPHanziPenW3-GBERRO.ttf", './ziti/一看就是大夫写的.ttf',
#                     './ziti/傲世九重天.ttf', './ziti/准备结婚系统系统.ttf', './ziti/凡人行书.ttf', './ziti/变更大夏.ttf',
#                     './ziti/呵呵呵呵呵鸡体.ttf', './ziti/哈嚓喇呱体.ttf', './ziti/哦哦好你付款.ttf', './ziti/喵系.ttf',
# 	                './ziti/好久嘻嘻.ttf', './ziti/小雯雯小可爱大可爱哈.ttf', './ziti/巩草.ttf', './ziti/张怡冉字体.ttf',
#                     './ziti/彤彤砸.ttf', './ziti/恨到爱.ttf','./ziti/惊涛骇浪.ttf', './ziti/我己不知我为何这么帅.ttf',
#                     './ziti/把侧妃呵呵.ttf', './ziti/束安琪.ttf', './ziti/林泽西酒体.ttf', './ziti/潇笔.ttf',
#                     './ziti/爱你绵绵.ttf', './ziti/王者荣耀体验款.ttf', './ziti/眠心.ttf', './ziti/细不细.ttf',
#                     './ziti/花开有时.ttf', './ziti/草草草草草草书.ttf', './ziti/落雨无情落花心.ttf',
#                     './ziti/陈氏家族体.ttf', './ziti/陌尚卿.ttf', './ziti/t1zt.ttf', './ziti/t2zt.ttf',
#                     './ziti/t3zt.ttf', './ziti/t4zt.ttf', './ziti/t5zt.ttf', './ziti/t6zt.ttf', './ziti/t7zt.ttf'
#                     , './ziti/t8zt.ttf', './ziti/t9zt.ttf', './ziti/t10zt.ttf', './ziti/t12zt.ttf']
#
#
# }


'''-------------------------远程配置----------------------'''
confingData={
    'DomainName':'https://handwrite.top:5009',
    "Img_return":"https://handwrite.top:5009/static",
    'mysqlPassword':"tZ8eLkabANGkHARt",
    'mysqlHost':'124.223.188.181',

    #字体地址列表
    "zitilist":[    "./ziti/青叶手写体.ttf", "./ziti/李国夫手写体.ttf", "./ziti/义启手写体.ttf", "./ziti/云烟体.ttf",
                    "./ziti/jmt.ttf","./ziti/extrabold.ttf", "./ziti/BoLeYaYati.ttf", "./ziti/伯乐童年体.ttf",
                    "./ziti/FZJingLeiS-R-GB.ttf","./ziti/DFPHanziPenW3-GB.ttf","./ziti/李国夫手写体ERRO.ttf",
                    "./ziti/义启手写体ERRO.ttf", "./ziti/云烟体ERRO.ttf", "./ziti/jmtERRO.ttf",
                    "./ziti/extraboldERRO.ttf", "./ziti/BoLeYaYatiERRO.ttf", "./ziti/伯乐童年体ERRO.ttf",
                    "./ziti/FZJingLeiS-R-GBERRO.ttf","./ziti/DFPHanziPenW3-GBERRO.ttf", './ziti/一看就是大夫写的.ttf',
                    './ziti/傲世九重天.ttf', './ziti/准备结婚系统系统.ttf', './ziti/凡人行书.ttf', './ziti/变更大夏.ttf',
                    './ziti/呵呵呵呵呵鸡体.ttf', './ziti/哈嚓喇呱体.ttf', './ziti/哦哦好你付款.ttf', './ziti/喵系.ttf',
	                './ziti/好久嘻嘻.ttf', './ziti/小雯雯小可爱大可爱哈.ttf', './ziti/巩草.ttf', './ziti/张怡冉字体.ttf',
                    './ziti/彤彤砸.ttf', './ziti/恨到爱.ttf','./ziti/惊涛骇浪.ttf', './ziti/我己不知我为何这么帅.ttf',
                    './ziti/把侧妃呵呵.ttf', './ziti/束安琪.ttf', './ziti/林泽西酒体.ttf', './ziti/潇笔.ttf',
                    './ziti/爱你绵绵.ttf', './ziti/王者荣耀体验款.ttf', './ziti/眠心.ttf', './ziti/细不细.ttf',
                    './ziti/花开有时.ttf', './ziti/草草草草草草书.ttf', './ziti/落雨无情落花心.ttf',
                    './ziti/陈氏家族体.ttf', './ziti/陌尚卿.ttf', './ziti/t1zt.ttf', './ziti/t2zt.ttf',
                    './ziti/t3zt.ttf', './ziti/t4zt.ttf', './ziti/t5zt.ttf', './ziti/t6zt.ttf', './ziti/t7zt.ttf'
                    , './ziti/t8zt.ttf', './ziti/t9zt.ttf', './ziti/t10zt.ttf', './ziti/t12zt.ttf']


}