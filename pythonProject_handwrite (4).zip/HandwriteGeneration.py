import json
import random
import time

from PIL import Image, ImageFont
from handright import Template, handwrite
from flask import Blueprint,jsonify, request

from Model.DataDB import common_dbManageData
from confing import confingData


HANDWRITEGeneration = Blueprint("HANDWRITEGeneration", __name__)

'''本项目要求后台模板的参数除了背景图片、字体可以供用户选择，Template中的参数一个都不许改动'''
'''图片背景（int）要与模板的（int）参数一致'''


@HANDWRITEGeneration.route("/wx/api/sxzGeneration", methods=['POST'])
def sxzGeneration():
    form = request.get_json()
    print(form)
    ds = 0    #特性选择 --》 底色
    zz = 0    #特性选择 --》 褶皱
    gy = 0    #特性选择 --》 光影

    text = request.get_json()["text"]  # 用户要生成的text
    bgid = request.get_json()["bgid"]  # 用户选中要生产的背景图片
    ztid = request.get_json()["ztid"]  # 用户选中要生产的字体

    red, green, blue, zspjj, zspjj_, zszjj, zszjj_, ztdx, ztdx_, spbhwy_, szbhwy_, bhxz_, \
        bianju_up, bianju_left, bianju_right, bianju_down = getmoban(int(bgid))

    try:
        if form["ztzyjianju"] != "":
            zspjj = form["ztzyjianju"]

        if form["ztdx_"] != "":
            ztdx_ = int(form["ztdx_"])

        if form["zspjj_"] != "":
            zspjj_ = int(form["zspjj_"])

        if form["spbhwy_"] != "":
            spbhwy_ = int(form["spbhwy_"])

        if form["szbhwy_"] != "":
            szbhwy_ = int(form["szbhwy_"])

        if form["bhxz_"] != "":
            bhxz_ = form["bhxz_"]

        red = form["red"]
        green = form["green"]
        blue = form["blue"]
    except:
        pass

    try:
        gy = form["gy"]
        zz = form["zz"]
        ds = form["ds"]
    except:
        pass

    '''自定义更多图片的id'''
    beijing = f"./img/bg{int(bgid)}.jpg"


    zitilist = confingData["zitilist"]
    ziti1 = zitilist[int(ztid)]  # 要执行的字体

    template = Template(
        background=Image.open(beijing),
        font=ImageFont.truetype(ziti1, size=int(ztdx)),
        line_spacing=int(zszjj),
        fill=(int(red), int(green), int(blue)),  # 字体“颜色”
        left_margin=int(bianju_left),
        top_margin=int(bianju_up),
        right_margin=int(bianju_right) - int(zspjj) * 2,
        bottom_margin=int(bianju_down),
        word_spacing=int(zspjj),
        line_spacing_sigma=int(zszjj_),  # 行间距随机扰动
        font_size_sigma=int(ztdx_),  # 字体大小随机扰动
        word_spacing_sigma=int(zspjj_),  # 字间距随机扰动
        end_chars="，。",  # 防止特定字符因排版算法的自动换行而出现在行首
        perturb_x_sigma=int(spbhwy_),  # 笔画横向偏移随机扰动
        perturb_y_sigma=int(szbhwy_),  # 笔画纵向偏移随机扰动
        perturb_theta_sigma=float(bhxz_),  # 笔画旋转偏移随机扰动

    )
    images = handwrite(text, template)
    ResImgList = []

    for i, im in enumerate(images):
        assert isinstance(im, Image.Image)
        t = random.randint(1, 10000)
        t1 = int(time.time())
        try:
            if gy:
                # 加载特效图片
                im_tx_gy = Image.open("./SpecialEffects/gy/gy{}.jpg".format(gy))
                # # 加载商品图片
                # im2 = Image.open("D:\pythonProject_handwrite\static\output\\1671871279_815.jpg")
                # 将特效照片与生成的图片大小调整到一置
                im1 = im_tx_gy.resize(im.size)
                im.paste(im1, (0, 0), im1)

            if zz:
                im_tx_zz = Image.open("./SpecialEffects/zz/zz{}.jpg".format(zz))
                im1 = im_tx_zz.resize(im.size)
                im.paste(im1, (0, 0), im1)

            if ds:
                im_tx_ds = Image.open("./SpecialEffects/ds/ds{}.jpg".format(ds))
                im1 = im_tx_ds.resize(im.size)
                im.paste(im1, (0, 0), im1)

            w, h = im.size
            im.thumbnail((w //2, h // 2))
            im.save("./static/output/{}_{}.jpg".format(t1, t))
            ResImgList.append(confingData["Img_return"] + "/output/{}_{}.jpg".format(t1, t))
            # return jsonify({"imgurl": ResImgList})   #这是只允许用户生成一张图片

        except:
            w, h = im.size
            im.thumbnail((w // 2, h // 2))
            im.save("./static/output/{}_{}.jpg".format(t1, t))
            ResImgList.append(confingData["Img_return"] + "/output/{}_{}.jpg".format(t1, t))
            # return jsonify({"imgurl": ResImgList})  # 这是只允许用户生成一张图片

    '''
    将生成的图片链接保存到数据库
    '''

    print(ResImgList)
    sql = f'''INSERT INTO record_generation (openId,imgurls,imgconut) VALUES ('{form['openid']}','{json.dumps(ResImgList)}',{len(ResImgList)});'''
    common_dbManageData(sql=sql)

    return jsonify({"imgurl": ResImgList})   #这是允许用户生成所有文字的图片



def getmoban(mb_id):

    shuju = []
    with open(file=f'moban/mb{mb_id}', mode='r+', encoding='utf-8') as f:
        for line in f.readlines():
            line = line.strip('\n')  # 去掉列表中每一个元素的换行符
            shuju.append(line)

    red = shuju[0]
    green = shuju[1]
    blue = shuju[2]
    # self.lineEdit.setText(shuju[3])
    # self.lineEdit_2.setText(shuju[4])
    zspjj = shuju[5]
    zspjj_ = int(shuju[6])
    zszjj = shuju[7]
    zszjj_ = int(shuju[8])
    ztdx = shuju[9]
    ztdx_ = int(shuju[10])
    spbhwy_ = int(shuju[11])
    szbhwy_ = int(shuju[12])
    bhxz_ = float(shuju[13])
    bianju_up = shuju[14]
    bianju_left = shuju[15]
    bianju_right = shuju[16]
    bianju_down = shuju[17]
    f.close()
    return red, green, blue, zspjj, zspjj_, zszjj, zszjj_, ztdx, ztdx_, \
        spbhwy_, szbhwy_, bhxz_, bianju_up, bianju_left, bianju_right, bianju_down



if __name__ == '__main__':
    sxzGeneration()
