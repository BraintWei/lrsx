from flask import Flask

from HandwriteGeneration import HANDWRITEGeneration
from daanquan import DaAnQuan
from goupibutong import Goupibutong
from morePapers import WX_MOREPAPERS

from qushuiyin import QuWaterM
from sec_check import SEC_CHECK
from uploadImg import UpImg
from wx_Login import WX_LOGIN

app = Flask(__name__)
app.secret_key='****----'
urls=[HANDWRITEGeneration,WX_LOGIN,WX_MOREPAPERS,
      SEC_CHECK,Goupibutong,DaAnQuan,UpImg,QuWaterM]      #将三个路由构建数组

for url in urls:
    app.register_blueprint(url)   #将三个路由均实现蓝图注册到主app应用上

if __name__ == '__main__':
    app.run(port=5008)

