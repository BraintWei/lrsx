import base64
import time
import requests
from flask import Blueprint, json, jsonify, request

from Model.DataDB import getData_UserInfo, insert_UserInfo, modifyData_UserInfo
from confing import confingData

WX_LOGIN = Blueprint("WX_LOGIN", __name__)

'''***************微信小程序登陆 模块**************************'''

@WX_LOGIN.route("/wx/api/getopenID/<code>")
def getopenid(code):
    secret = "2bbe277fda62625edaed1d9c36940583"
    appid = "wx4f95182ca0c886a8"
    grant_type = 'authorization_code'
    url = "https://api.weixin.qq.com/sns/jscode2session?appid={}&secret={}&js_code={}&grant_type={}".format(appid,
                                                                                                            secret,
                                                                                                            code,
                                                                                                            grant_type)
    try:
        res = requests.get(url=url)
        res = json.loads(res.text)
        try:
            if res['openid']:
                return jsonify({'code': 200, 'openid': res['openid'],'msg': 'openid获取成功'})
        except:
            return jsonify({'code': -1,'msg': 'openid获取失败'})
    except:

        return jsonify({'code': -2,'msg': 'openid获取失败'})





@WX_LOGIN.route("/wx/api/lrsx/saveUserInfo",methods=['POST'])
def saveUserInfo():
    try:
        form = request.get_json()
        filename = './static/WxUserTouXiangImg/{}.jpg'.format(form['openid'])
        imgdata = base64.b64decode(form['avatarUrlImage'])
        imgurl = confingData['DomainName'] + f"/static/WxUserTouXiangImg/{form['openid']}.jpg"
        with open(filename, 'wb') as f:
            f.write(imgdata)
        length = len(getData_UserInfo(tableName='user_info',openid=form['openid']))
        if length:
            if modifyData_UserInfo(tableName='user_info',avatarUrlImage=imgurl,nickname=form['Nickname'],openid=form['openid']):
                return jsonify({'code': 200, 'msg': '用户信息修改成功', 'imgurl': imgurl})
            else:
                return jsonify({'code': -1, 'msg': '禁止使用非法字符昵称', 'imgurl': ''})

        else:
            if insert_UserInfo(tableName='user_info',openid=form['openid'],avatarUrlImage=imgurl,nickname=form['Nickname']):
                return jsonify({'code': 200, 'msg': '用户信息保存成功', 'imgurl': imgurl})
            else:
                return jsonify({'code': -1, 'msg': '禁止使用非法字符昵称', 'imgurl': ''})
    except:
        return jsonify({'code': -1, 'msg': '禁止使用非法字符昵称', 'imgurl': ''})



def access_token():
    secret = "2bbe277fda62625edaed1d9c36940583"
    appid = "wx4f95182ca0c886a8"
    url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + appid + "&secret=" + secret
    res = requests.get(url=url).text

    r = json.loads(res)
    token = r['access_token']
    now = time.time()  # 返回float数据

    Note = open('access_token.txt', mode='w')
    Note.write(token + "||" + str(int(now) + 7100))
    Note.close()
    print("成功获取新的access_token")
    return token
