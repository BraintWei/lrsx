

import json
import re

import requests


def fenxiurl(text):

    url = re.search(r'https://v.douyin.com/\w+', text).group()
    print("提取的URL为:", url)
    return url


def getlocationUrl(shareurl):
    url=shareurl
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'Connection': 'keep-alive',
        'Cookie': 'ttwid=1%7Ccz2s0jiB_-S_c7z3FTruRl0jTbvEskSdSP2TB62RNPw%7C1709186409%7C5862bffd79537f12722fbd394d3dc897436755f0e73e7d24989989a8f03b0a18; FORCE_LOGIN=%7B%22videoConsumedRemainSeconds%22%3A180%7D; strategyABtestKey=%221709186414.011%22; passport_csrf_token=222290fda86d484f746f1e521a54fec2; passport_csrf_token_default=222290fda86d484f746f1e521a54fec2; bd_ticket_guard_client_web_domain=2; volume_info=%7B%22isUserMute%22%3Afalse%2C%22isMute%22%3Atrue%2C%22volume%22%3A0.7%7D; pwa2=%220%7C0%7C3%7C0%22; stream_recommend_feed_params=%22%7B%5C%22cookie_enabled%5C%22%3Atrue%2C%5C%22screen_width%5C%22%3A1536%2C%5C%22screen_height%5C%22%3A864%2C%5C%22browser_online%5C%22%3Atrue%2C%5C%22cpu_core_num%5C%22%3A16%2C%5C%22device_memory%5C%22%3A8%2C%5C%22downlink%5C%22%3A8.2%2C%5C%22effective_type%5C%22%3A%5C%224g%5C%22%2C%5C%22round_trip_time%5C%22%3A50%7D%22; bd_ticket_guard_client_data=eyJiZC10aWNrZXQtZ3VhcmQtdmVyc2lvbiI6MiwiYmQtdGlja2V0LWd1YXJkLWl0ZXJhdGlvbi12ZXJzaW9uIjoxLCJiZC10aWNrZXQtZ3VhcmQtcmVlLXB1YmxpYy1rZXkiOiJCRVcrdHcrcjNTaWR1RTQ0eGhXWTBGOWhEeFE3VWVNbDJRZ1NrYVFjM056N1dYTDdKUW5nVXBBWFg0eGQvTm02S1FLY3V3QnphVXNGWnMvbXFWNWhCSzA9IiwiYmQtdGlja2V0LWd1YXJkLXdlYi12ZXJzaW9uIjoxfQ%3D%3D; home_can_add_dy_2_desktop=%221%22; download_guide=%223%2F20240229%2F1%22; msToken=mFuc7AlGB9tNUMMxep5I1uJk7ZYXMfW08U2hR55ji7BiQqm8PQqo0OqMwQh-lpe-lkwVtG8ZgcHYvLQiGc1pPxi1Nf1cisdRWwKxO92jKi_MP5PRBw==; IsDouyinActive=false',
        'Host': 'v.douyin.com',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1 Edg/122.0.0.0',

    }
    res=requests.get(url=url,headers=headers, verify=True, allow_redirects=False)
    Locationurl=res.headers['Location']
    # print(Locationurl)
    return Locationurl


def getvideoUrl(Locationurl):
    # 使用正则表达式提取数字部分
    video_id = re.search(r'/(\d+)/\?', Locationurl).group(1)

    # print("提取的视频ID为:", video_id)

    headers = {
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'Connection': 'keep-alive',
        'Cookie': 'ttwid=1%7Ccz2s0jiB_-S_c7z3FTruRl0jTbvEskSdSP2TB62RNPw%7C1709186409%7C5862bffd79537f12722fbd394d3dc897436755f0e73e7d24989989a8f03b0a18; dy_swidth=1536; dy_sheight=864; csrf_session_id=ac1b4fc526be004d34a5785820329d7b; FORCE_LOGIN=%7B%22videoConsumedRemainSeconds%22%3A180%7D; strategyABtestKey=%221709186414.011%22; passport_csrf_token=222290fda86d484f746f1e521a54fec2; passport_csrf_token_default=222290fda86d484f746f1e521a54fec2; bd_ticket_guard_client_web_domain=2; ttcid=8438186ffa1c4af68418fe8a654e6bdd25; volume_info=%7B%22isUserMute%22%3Afalse%2C%22isMute%22%3Atrue%2C%22volume%22%3A0.7%7D; pwa2=%220%7C0%7C3%7C0%22; s_v_web_id=verify_lt6tt87p_f3cdfc0a_eb3f_27c4_4a18_eb578f927968; bd_ticket_guard_client_data=eyJiZC10aWNrZXQtZ3VhcmQtdmVyc2lvbiI6MiwiYmQtdGlja2V0LWd1YXJkLWl0ZXJhdGlvbi12ZXJzaW9uIjoxLCJiZC10aWNrZXQtZ3VhcmQtcmVlLXB1YmxpYy1rZXkiOiJCRVcrdHcrcjNTaWR1RTQ0eGhXWTBGOWhEeFE3VWVNbDJRZ1NrYVFjM056N1dYTDdKUW5nVXBBWFg0eGQvTm02S1FLY3V3QnphVXNGWnMvbXFWNWhCSzA9IiwiYmQtdGlja2V0LWd1YXJkLXdlYi12ZXJzaW9uIjoxfQ%3D%3D; download_guide=%223%2F20240229%2F1%22; __ac_nonce=065e02df2005de50d59b5; __ac_signature=_02B4Z6wo00f01IK3dwQAAIDD9JiqSo5mU2iCl3OAAEVSVNe1BnRESV0eXNYgjEOmChXpBdZQ5KR0DGw3XVc66UTe3xUA2Hn.7q1F7W-ySFvFiqyn5P3losTdtqJJ6vN1Oa.nYq6m4XQYdEt373; msToken=_AyM2hmAmsKJydC43v0isPOFj50E7hcgoCUvV1hIsftfuY2WsVL8-zleIZ9dcg7xt0YL_LJtgm_-2TxNpYmFTXDzIVKgm9l9mQGFeho1Fg-KudOj_wyv7Jl95fE=; tt_scid=b80MjmyWcFgAXuvrsRJXht2kVfMdygyFP-8x8P8B0.brtrx75kaTtikSN6eL7MF4195b; msToken=zGV2BHs_FQ6T90AQS6xZBl9Z6A19su1KaRgifkErkAi11AWGhSE-d_3j74G1uBIWMr0kflaLlQDhXSE7CzKp3bXJLQkPoig_DZtdPi3V_OjV42elVxJPM83__WQ=; IsDouyinActive=true; home_can_add_dy_2_desktop=%220%22; stream_recommend_feed_params=%22%7B%5C%22cookie_enabled%5C%22%3Atrue%2C%5C%22screen_width%5C%22%3A1536%2C%5C%22screen_height%5C%22%3A864%2C%5C%22browser_online%5C%22%3Atrue%2C%5C%22cpu_core_num%5C%22%3A16%2C%5C%22device_memory%5C%22%3A8%2C%5C%22downlink%5C%22%3A5.2%2C%5C%22effective_type%5C%22%3A%5C%224g%5C%22%2C%5C%22round_trip_time%5C%22%3A200%7D%22',
        'Host': 'www.douyin.com',
        'Referer': 'https://www.douyin.com/video/7340680543354375487',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0',
        'sec-ch-ua': '"Chromium";v="122", "Not(A:Brand";v="24", "Microsoft Edge";v="122"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',

    }
    url="https://www.douyin.com/aweme/v1/web/aweme/detail/?device_platform=webapp&aid=6383&channel=channel_pc_web&aweme_id="+video_id
    res=requests.get(url=url,headers=headers, verify=True, allow_redirects=False)
    # print(res.text)
    video_key=json.loads(res.text)['aweme_detail']['video']['bit_rate'][0]['play_addr']['uri']

    vurl='https://aweme.snssdk.com/aweme/v1/play/?video_id={}&ratio=720p&line=0'.format(video_key)
    # print(vurl)
    return vurl

from flask import Blueprint, jsonify, request, render_template

QuWaterM = Blueprint("QuWaterM",__name__)
@QuWaterM.route("/wx/QuWaterM/v1", methods=['POST','GET'])
def aaaa():
    try:
        form = request.get_json()
        Locationurl=getlocationUrl(fenxiurl(form['qrdata']))
        url=getvideoUrl(Locationurl=Locationurl)
        return jsonify({ 'status':1, 'data':{'playAddr':url}})
    except:
        return jsonify({'status': 0, 'msg': "该视频不支持 下载"})


if __name__ == '__main__':
    Locationurl=getlocationUrl("https://v.douyin.com/iNc6eGEE/")
    getvideoUrl(Locationurl=Locationurl)
