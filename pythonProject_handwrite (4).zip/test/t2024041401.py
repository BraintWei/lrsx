import json

from Model.DataDB import common_dbManageData, common_getData

# sql='''INSERT INTO record_generation (imgurls) VALUES ('['http://127.0.0.1:5008/static/output/1713087589_6644.jpg']');'''
sql='''SELECT * FROM record_generation WHERE id=5;
'''

print(type(json.loads(common_getData(sql=sql)[0]['imgurls'])))