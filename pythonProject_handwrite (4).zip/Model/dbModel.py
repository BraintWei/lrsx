'''数据库连接'''
'''
正常版本 正是模板

'''

import pymysql

import confing


class dbConnect():
    def __init__(self):
        self.password=confing.confingData['mysqlPassword']
        self.host=confing.confingData['mysqlHost']
        self.conn = None
        self.cursor = None
        self.connect()

    def connect(self):
            try:
                # 根据需要选择本地或远程连接信息
                self.conn = pymysql.connect(
                    user='root',
                    password=self.password,
                    database='project_lrsxtpro',
                    host=self.host,
                    charset='utf8',
                    cursorclass=pymysql.cursors.DictCursor

                )
                self.cursor = self.conn.cursor()
            except Exception as e:
                print(f"数据库连接错误：{e}")




    def dbManage(self,sql=None):
        '''
        实现对数据表里的定义、增加、删除、修改操作
        :param sql:
        :return:
        '''
        flag = False
        # 检查数据库连接是否存在，不存在则重新连接
        if not self.conn or not self.cursor:
            self.connect()
        try:

            self.conn.ping(reconnect=True)

            self.cursor.execute(sql)
            self.conn.commit()
            self.conn.autocommit(True)
            flag=True
        except Exception as e:
            print(e)
            self.conn.rollback()
        return flag

    def dbQuery(self,sql):
        '''
        数据库的查询业务
        :param sql:
        :return:
        '''
        # 检查数据库连接是否存在，不存在则重新连接
        if not self.conn or not self.cursor:
            self.connect()
        try:
            self.conn.ping(reconnect=True)
            self.cursor.execute(sql)
            self.conn.autocommit(True)
            return  self.cursor.fetchall()
        except Exception as e:
            # return "不知道为什么查不到数据"
            print("操作出现错误：{}".format(e))
            self.conn.rollback()

if __name__=='__main__':
    d = dbConnect()
    print(d.dbQuery("select * from user_info"))