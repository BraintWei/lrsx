'''
数据库的业务
'''

from Model.dbModel import dbConnect

db = dbConnect()


def common_getData(sql):
    # 通用的数据库查询函数  传入sql语句
    return db.dbQuery(sql=sql)


def common_dbManageData(sql):
    # 通用的数据库 增 删 改  函数  传入sql语句
    return db.dbManage(sql=sql)


def getData_UserInfo(tableName, openid):
    return db.dbQuery(sql="select * from {} where openid='{}' ".format(tableName, openid))


def insert_preChargeOrder(tableName, openid, Pre_chargetime, out_trade_no, sign, total_fee):
    sql = "insert into {} values(null,'{}','{}','{}','{}','{}')".format(tableName, openid, Pre_chargetime, out_trade_no,
                                                                        sign, total_fee)
    return db.dbManage(sql=sql)


def insert_UserInfo(tableName, openid, avatarUrlImage, nickname):
    sql = "insert into {} (openid,avatarUrlImage,nickname) values('{}','{}','{}')".format(tableName, openid,
                                                                                          avatarUrlImage, nickname)
    return db.dbManage(sql=sql)


def del_hlwtoken(tableName, openid):
    return db.dbManage(sql="delete from {} where openid='{}'".format(tableName, openid))


def modifyData_successchargeorder(tableName, id):
    return db.dbManage(sql="update {} set pay_ok='1' where out_trade_no='{}' ".format(tableName, id))


def modifyData_UserInfo(tableName, avatarUrlImage, nickname, openid):
    return db.dbManage(
        sql="update {} set  avatarUrlImage='{}', nickname='{}' where openid='{}' ".format(tableName, avatarUrlImage,
                                                                                          nickname, openid))


if __name__ == '__main__':
    print(getData_UserInfo(tableName='user_info', openid='df'))
