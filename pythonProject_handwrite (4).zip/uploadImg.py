import base64
import random
import re
import time
from io import BytesIO

from PIL import Image, ImageFont
from flask import Blueprint, request, jsonify
from handright import handwrite, Template

from confing import confingData

UpImg = Blueprint("UpImg",__name__)

@UpImg.route("/wx/UpImg2", methods=['POST'])
def upImg2():
    imageObject = request.get_json()['img']
    imgdata = base64.b64decode(imageObject)
    t = random.randint(1, 10000)
    t1 = int(time.time())
    filename = './static/ZdyImage/Img_{}_{}.jpg'.format(t1, t)  # I assume you have a way of picking unique filenames

    with open(filename, 'wb') as f:
        f.write(imgdata)
    return jsonify({"code":200,"imgurl":[confingData["Img_return"] +"/ZdyImage/Img_{}_{}.jpg".format(t1, t)]})


@UpImg.route("/wx/UpImg1", methods=['POST'])
def upImg():
    # print(request.get_json())
    imageObject = str(request.get_json()['zdyimgUrl'])
    imgUrl=imageObject[imageObject.index("static"):]
    # print(imgUrl)
    # base64_data = re.sub('^data:image/.+;base64,', '', imageObject)
    # byte_data = base64.b64decode(base64_data)
    # image_data = BytesIO(byte_data)
    try:
        img = Image.open(imgUrl)
    except:
        print("没有找到图片")
    # ds = 0
    # zz = 0
    # gy = 0
    bgid = 0  # 用户选中要生产的背景图片
    ztid = 1  # 用户选中要生产的字体
    # tpmode=  request.get_json()["tpmode"]
    # red, green, blue, zspjj, zspjj_, zszjj, zszjj_, ztdx, ztdx_, spbhwy_, szbhwy_, bhxz_, \
    #     bianju_up, bianju_left, bianju_right, bianju_down = getmoban(int(bgid))
    red=0
    green=0
    blue=0
    text = request.get_json()["text"]

    ztid = request.get_json()["ztid"]    #生成的字体

    bianju_up = request.get_json()["bianju_up"]

    bianju_right= request.get_json()["bianju_right"]

    bianju_down= request.get_json()["bianju_down"]

    bianju_left = request.get_json()["bianju_left"]

    ztdx=request.get_json()["ztdx"]

    ztdx_=request.get_json()["ztdx_"]

    zspjj=request.get_json()["zspjj"]

    zspjj_ = request.get_json()["zspjj_"]

    zszjj=request.get_json()["zszjj"]

    zszjj_=request.get_json()["zszjj_"]

    spbhwy_=request.get_json()["spbhwy_"]     #//笔画横向偏移扰动
    szbhwy_=request.get_json()["szbhwy_"]       #//笔画纵向偏移扰动
    bhxz_=request.get_json()["bhxz_"]      #//笔画旋转偏移扰动

    # try:
    #     gy = request.get_json()["gy"]
    #     zz = request.get_json()["zz"]
    #     ds = request.get_json()["ds"]
    # except:
    #     pass

    # beilinglist = confingData["beilinglist"]
    # beijing = beilinglist[int(bgid)]  # 要执行的背景

    zitilist = confingData["zitilist"]

    ziti1 = zitilist[int(ztid)]  # 要执行的字体

    template = Template(
        # background=Image.open("C:/Users/wei/Desktop/手写模拟器/background/background_01.jpg"),
        background=img,
        # background=Image.new(mode="1", size=(900, 1000), color=1),
        # font=ImageFont.truetype("D:\hand-write-main\Fonts\青叶手写体.ttf", size=int(ztdx)),
        font=ImageFont.truetype(ziti1, size=int(ztdx)),
        line_spacing=int(zszjj),
        fill=(int(red), int(green), int(blue)),  # 字体“颜色”
        left_margin=int(bianju_left),
        top_margin=int(bianju_up),
        right_margin=int(bianju_right) - int(zspjj) * 2,
        bottom_margin=int(bianju_down),
        word_spacing=int(zspjj),
        line_spacing_sigma=int(zszjj_),  # 行间距随机扰动
        font_size_sigma=int(ztdx_),  # 字体大小随机扰动
        word_spacing_sigma=int(zspjj_),  # 字间距随机扰动
        end_chars="，。",  # 防止特定字符因排版算法的自动换行而出现在行首
        perturb_x_sigma=int(spbhwy_),  # 笔画横向偏移随机扰动
        perturb_y_sigma=int(szbhwy_),  # 笔画纵向偏移随机扰动
        perturb_theta_sigma=float(bhxz_),  # 笔画旋转偏移随机扰动

    )
    images = handwrite(text, template)
    ResImgList = []
    for i, im in enumerate(images):
        assert isinstance(im, Image.Image)
        # im.show()
        t = random.randint(1, 10000)
        t1 = int(time.time())

        w, h = im.size
        im.thumbnail((w // 5, h // 5))
        im.save("./static/output/{}_{}.jpg".format(t1, t))
        ResImgList.append(confingData["Img_return"] + "/{}_{}.jpg".format(t1, t))
        return jsonify({"imgurl": ResImgList})



if __name__ == '__main__':
    pass