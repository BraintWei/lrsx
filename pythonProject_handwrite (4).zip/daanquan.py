import json
import re
import time

import requests
from flask import Blueprint, jsonify, request

DaAnQuan = Blueprint("DaAnQuan",__name__)
@DaAnQuan.route("/wx/DaAnQuan/<nijiid>/<searchName>", methods=['GET'])
def daAnQuan(nijiid,searchName):
    url = "http://m.mxqe.com/e/search/index.php?keyboard="+searchName+"&Submit22=&show=title&tempid=1&searchget=1"
    res = requests.get(url=url, allow_redirects=False)
    searchid = ""
    try:
        zzsearchid = r"searchid=(.*?)',"
        searchid = re.findall(zzsearchid, str(res.headers), re.M | re.S)[0]
        # print(searchid)
    except:
        print("没有匹配到")

    time.sleep(1)
    url1 = "http://m.mxqe.com/e/search/result/index.php?searchid=" + searchid + "&nianji="+nijiid+"&kemu=0&ce=0"
    res = requests.get(url=url1, allow_redirects=False).text
    # print(res)
    clist=[]
    try:
        zzcont = r'class="m-news-cont"(.*?)</div>'
        contlist = re.findall(zzcont, str(res), re.M | re.S)
        # print(contlist)
        for t in contlist:
            # print(t)
            zzimgsrc = r'src="(.*?)"'
            imgsrc = re.findall(zzimgsrc, t, re.M | re.S)
            zztitle = r'html">(.*?)<'
            title = re.findall(zztitle, t, re.M | re.S)
            zztagname = r'tagname=(.*?)"'
            tagname = re.findall(zztagname, t, re.M | re.S)
            zznextUrl = r'href="(.*?)" class="u-img">'
            nextUrl = re.findall(zznextUrl, t, re.M | re.S)
            # print(imgsrc, title, tagname,nextUrl)
            clist.append({"imgsrc":imgsrc,"title":title,"tagname":tagname,"nextUrl":nextUrl})
            # return jsonify({"imgsrc":imgsrc,"title":title,"tagname":tagname})

        return  jsonify({"content":clist,"searchid":searchid})
    except:
        print("没有匹配到")

@DaAnQuan.route("/wx/DaAnQuan/next/<p>/<searchid>/<nijiid>", methods=['GET'])
def daAnQuannext(p,searchid,nijiid):
    url = "http://m.mxqe.com/e/search/result/Ajax.php?&page="+p+"&searchid="+searchid+"&nianji&nianji="+nijiid+"&kemu=0&ce=0 "
    res = requests.get(url=url, allow_redirects=False).text
    # print(res)
    res = json.loads(res)
    cnextlist=[]
    for o in res:
        # print(o)
        cnextlist.append({"imgsrc": [o["34"]], "title": [o["28"]], "tagname": [o["27"]],"nextUrl":[o["titleurl"]]})
        # print([o["28"]], [o["27"]], [o["34"]])
    return jsonify({"content":cnextlist})


@DaAnQuan.route("/wx/DaAnQuan1/ee", methods=['GET'])
def daAnQuantitleurl():
    # print("11111111")
    titleurl=request.args.get('titleurl')
    # print(titleurl,"555")
    url = "http://m.mxqe.com/"+titleurl

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.87 Safari/537.36 OPR/37.0.2178.32"
    }
    res = requests.get(url=url, headers=headers)
    res.encoding = "utf-8"
    # print(res.text)
    zzcontent = r'<p style="text-align: center">(.*?)查看更多答案'
    content = re.findall(zzcontent, res.text, re.M | re.S)
    # print(content)
    src = []
    title = "1"
    for t in content:
        zzsrc = r'src="(.*?)"'
        src = re.findall(zzsrc, t, re.M | re.S)
        # zztitle = r'title="(.*?)"'
        # title = re.findall(zztitle, t, re.M | re.S)[0]
        print(src)
    return jsonify({"imgurl":src})