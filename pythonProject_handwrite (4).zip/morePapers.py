import base64
import time
import requests
from flask import Blueprint, json, jsonify, request

from Model.DataDB import getData_UserInfo, insert_UserInfo, modifyData_UserInfo, common_getData
from confing import confingData

WX_MOREPAPERS = Blueprint("WX_MOREPAPERS", __name__)

@WX_MOREPAPERS.route("/wx/api/get_morepapers", methods=['POST'])
def getmorepapers():
    sql = '''SELECT * FROM morepapers ;'''
    res = common_getData(sql=sql)
    print(res)

    return jsonify({"code":"200","content" : res ,"msg":""})