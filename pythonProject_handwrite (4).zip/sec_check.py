import time
import requests
from flask import Blueprint, json, jsonify, request

from wx_Login import access_token

'''微信小程序 对用户文字 图片进行安全检测'''
SEC_CHECK = Blueprint("SEC_CHECK", __name__)


@SEC_CHECK.route("/wx/api/msg_sec_check", methods=['POST'])
def checkerro_wz():
    t = request.get_json()['t']  # 检测用户的文字是否存在违规

    Note1 = open('access_token.txt', mode='r')

    res = Note1.read()
    token, effective_time = res.split("||")
    Note1.close()

    now = time.time()  # 返回float数据
    if int(now) > int(effective_time):  # 表明access_token 已经失效了
        token = access_token()  # 重新获取token
        url = "https://api.weixin.qq.com/wxa/msg_sec_check?access_token={}".format(token)
        data = {
            'content': t
        }
        data = json.dumps(data, ensure_ascii=False).encode('utf-8')
        res = requests.post(url=url, data=data).text
        return res

    else:
        url = "https://api.weixin.qq.com/wxa/msg_sec_check?access_token={}".format(token)
        data = {
            'content': t
        }
        data = json.dumps(data, ensure_ascii=False).encode('utf-8')
        res = requests.post(url=url, data=data).text
        return res


@SEC_CHECK.route("/wx/api/msg_sec_img", methods=['POST'])  # 检测用户的图片是否存在违规
def checkImgByApi():
    imageObject = request.get_json()['img']

    Note1 = open('access_token.txt', mode='r')

    res = Note1.read()
    token, effective_time = res.split("||")
    Note1.close()
    now = time.time()  # 返回float数据
    if int(now) > int(effective_time):
        token = access_token()  # 重新获取token

        wxAPI = "https://api.weixin.qq.com/wxa/img_sec_check?access_token={}".format(token)

        headers = {"Content-Type": "multipart/form-data"}
        # 由于微信接收的图片限制未不高于1m，需要判断图片大小后做一些压缩，再提交
        # imageObject = #压缩后
        post_files = {
            "media": imageObject,
        }
        response = requests.post(
            url=wxAPI,
            files=post_files,
            headers=headers
        )
        response.encoding = 'utf-8'  # 设置可接收的编码为 utf-8
        print(response.text)
        return response.text


    else:

        wxAPI = "https://api.weixin.qq.com/wxa/img_sec_check?access_token={}".format(token)

        headers = {"Content-Type": "multipart/form-data"}
        # 由于微信接收的图片限制未不高于1m，需要判断图片大小后做一些压缩，再提交
        # imageObject = #压缩后
        post_files = {
            "media": imageObject,
        }
        response = requests.post(
            url=wxAPI,
            files=post_files,
            headers=headers
        )
        response.encoding = 'utf-8'  # 设置可接收的编码为 utf-8
        print(response.text)
        return response.text